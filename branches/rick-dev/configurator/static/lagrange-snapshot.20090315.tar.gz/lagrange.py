#!/usr/bin/env python
import sys
import lagrange
print lagrange.msg

outfile = sys.stdout
data = file(sys.argv[1]).read()
model, tree, data = lagrange.input.eval_decmodel(data)
lagrange.output.ascii_tree(outfile, tree, model, data)
d, e = lagrange.output.optimize_dispersal_extinction(outfile, tree, model)
lagrange.output.ancsplits(outfile, tree, model, d, e)
