import os
VERSION = file(os.path.join(os.path.dirname(__file__), "VERSION")).read().strip()

msg = """lagrange: likelihood analysis of geographic range evolution
Version 2 released February 2008
This is development snapshot %s
Authors: Richard Ree <rree@fieldmuseum.org>
         Stephen Smith <sasmith@nescent.org>
http://lagrange.googlecode.com
""" % VERSION

import input, output, nchoosem, optimize, ascii, newick, phylo, decmodel_mp
try:
    import graph
except:
    pass
try:
    from ratemodel import RateModel, RateModelGE, RateModelGE2, Ancsplit
except:
    pass
try:
    from decmodel_mp import DECModel
except:
    pass
from Nexus import Nexus
from tree import Tree
