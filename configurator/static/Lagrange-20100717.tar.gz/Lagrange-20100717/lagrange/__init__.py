import os
VERSION = file(
    os.path.join(os.path.dirname(__file__), "VERSION")
    ).read().strip()

msg = """Lagrange: likelihood analysis of geographic range evolution
Version: %s
Authors: Richard Ree <rree@fieldmuseum.org>
         Stephen Smith <sasmith@nescent.org>
http://lagrange.googlecode.com
""" % VERSION

import input, output, nchoosem, optimize, ascii, newick, phylo, decmodel_mp
import graph
try:
    from ratemodel import RateModel, RateModelGE, RateModelGE2, Ancsplit
except:
    pass
try:
    from decmodel_mp import DECModel
except:
    pass
from nexus import Nexus
from tree import Tree
